Program_2 - Unity project (rebuilt from the screen-share video)
Target editor: Unity 6000.6.3f1 (the version shown in the video) - Built-in Render Pipeline

HOW TO OPEN
1. Unzip.  2. Unity Hub -> Add -> "Add project from disk" -> pick the UnityProject_Program2 folder.
3. Open with Unity 6 (6000.6.3f1 if you have it).  4. SampleScene opens by itself.  Press Play.

SCENE
- Main Camera at eye height (0,1.6,0)   - Directional Light (Unity default)
- Screen  : Quad 4x2 at (0,2,6) with a VideoPlayer (Material Override) playing Assets/Prog2Vid.mp4, looping
- Plane   : teal, 30x30
- Canvas  : World Space, "Play (Press P)" and "Pause (Press O)" buttons
- EventSystem (+ EventSystemInputSetup adds the right UI input module)
- VideoController : VideoScreenController script wired to the VideoPlayer and both buttons

CONTROLS
- Click the Play / Pause buttons with the mouse
- Space = toggle, P = play, O = pause

VIDEO
Assets/Prog2Vid.mp4 is a generated placeholder (the original clip was not available).
To use your own: copy your clip over Assets/Prog2Vid.mp4 (keep the name), or select Screen and drag
your clip into Video Player > Video Clip.

If the keyboard shortcuts do nothing: Edit > Project Settings > Player > Other Settings >
Active Input Handling = "Both" (or "Input System Package (New)"), then restart the editor.
