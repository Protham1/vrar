using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine.SceneManagement;

// Opens Assets/Scenes/SampleScene.unity automatically the first time this project is opened,
// so you only have to press Play. It never overrides a scene you already have open.
[InitializeOnLoad]
public static class OpenSampleSceneOnLoad
{
    const string ScenePath = "Assets/Scenes/SampleScene.unity";
    const string SessionKey = "Program2.OpenSampleSceneOnLoad.Done";
    static int attempts;

    static OpenSampleSceneOnLoad()
    {
        if (SessionState.GetBool(SessionKey, false)) return;
        EditorApplication.update += TryOpen;
    }

    static void TryOpen()
    {
        if (++attempts > 2000) { Finish(); return; }
        if (EditorApplication.isCompiling || EditorApplication.isUpdating) return;
        if (EditorApplication.isPlayingOrWillChangePlaymode) { Finish(); return; }
        if (string.IsNullOrEmpty(AssetDatabase.AssetPathToGUID(ScenePath))) return; // not imported yet

        Scene active = SceneManager.GetActiveScene();
        if (string.IsNullOrEmpty(active.path) && !active.isDirty && File.Exists(ScenePath))
            EditorSceneManager.OpenScene(ScenePath, OpenSceneMode.Single);
        Finish();
    }

    static void Finish()
    {
        EditorApplication.update -= TryOpen;
        SessionState.SetBool(SessionKey, true);
    }
}
