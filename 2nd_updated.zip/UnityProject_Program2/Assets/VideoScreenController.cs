using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Video;
using UnityEngine.InputSystem;

public class VideoScreenController : MonoBehaviour
{
    [SerializeField] private VideoPlayer videoPlayer;
    [SerializeField] private Button playButton;
    [SerializeField] private Button pauseButton;

    [Header("Keyboard Controls")]
    [SerializeField] private Key togglePlayPauseKey = Key.Space;
    [SerializeField] private Key playKey = Key.P;
    [SerializeField] private Key pauseKey = Key.O;

    private void Start()
    {
        if (videoPlayer == null)
        {
            videoPlayer = GetComponent<VideoPlayer>();
        }

        if (playButton != null)
        {
            playButton.onClick.AddListener(PlayVideo);
        }

        if (pauseButton != null)
        {
            pauseButton.onClick.AddListener(PauseVideo);
        }
    }

    // NOTE: the video only shows the script down to Start(); everything below is a reconstruction.
    private void Update()
    {
        Keyboard keyboard = Keyboard.current;
        if (keyboard == null || videoPlayer == null)
        {
            return;
        }

        if (keyboard[togglePlayPauseKey].wasPressedThisFrame)
        {
            if (videoPlayer.isPlaying)
            {
                PauseVideo();
            }
            else
            {
                PlayVideo();
            }
        }

        if (keyboard[playKey].wasPressedThisFrame)
        {
            PlayVideo();
        }

        if (keyboard[pauseKey].wasPressedThisFrame)
        {
            PauseVideo();
        }
    }

    public void PlayVideo()
    {
        if (videoPlayer != null && !videoPlayer.isPlaying)
        {
            videoPlayer.Play();
        }
    }

    public void PauseVideo()
    {
        if (videoPlayer != null && videoPlayer.isPlaying)
        {
            videoPlayer.Pause();
        }
    }
}
