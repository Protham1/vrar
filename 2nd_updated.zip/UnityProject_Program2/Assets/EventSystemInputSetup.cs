using UnityEngine;
using UnityEngine.EventSystems;
#if ENABLE_INPUT_SYSTEM
using UnityEngine.InputSystem.UI;
#endif

// Adds the UI input module that matches the project's Active Input Handling setting,
// so the world-space Play / Pause buttons can be clicked with the mouse.
public class EventSystemInputSetup : MonoBehaviour
{
    private void Awake()
    {
        if (GetComponent<BaseInputModule>() != null)
        {
            return;
        }
#if ENABLE_INPUT_SYSTEM
        InputSystemUIInputModule module = gameObject.AddComponent<InputSystemUIInputModule>();
        module.AssignDefaultActions();
#else
        gameObject.AddComponent<StandaloneInputModule>();
#endif
    }
}
