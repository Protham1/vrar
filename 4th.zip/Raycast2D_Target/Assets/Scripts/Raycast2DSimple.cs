using UnityEngine;

// Attach to the "origin" object. Casts a 2D ray toward the mouse;
// the sprite it hits turns green, every other sprite turns red.
public class Raycast2DSimple : MonoBehaviour
{
    public float rayDistance = 5f;
    public Color hitColor = Color.green;
    public Color normalColor = Color.red;

    SpriteRenderer[] targets;
    LineRenderer line;

    void Start()
    {
        targets = FindObjectsOfType<SpriteRenderer>();

        // Visible ray in the Game view (Debug.DrawRay only shows with Gizmos on)
        line = gameObject.AddComponent<LineRenderer>();
        line.material = new Material(Shader.Find("Sprites/Default"));
        line.startWidth = line.endWidth = 0.05f;
        line.positionCount = 2;
        line.sortingOrder = 10;
    }

    void Update()
    {
        Vector3 mouseWorld = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        mouseWorld.z = 0f;

        Vector2 origin = transform.position;
        Vector2 direction = ((Vector2)mouseWorld - origin).normalized;

        RaycastHit2D hit = Physics2D.Raycast(origin, direction, rayDistance);

        ResetAllColors();
        if (hit.collider != null)
        {
            SpriteRenderer sr = hit.collider.GetComponent<SpriteRenderer>();
            if (sr != null) sr.color = hitColor;
        }

        Vector3 end = origin + direction * rayDistance;
        line.SetPosition(0, origin);
        line.SetPosition(1, end);
        line.startColor = line.endColor = normalColor;
        Debug.DrawRay(origin, direction * rayDistance, normalColor);
    }

    void ResetAllColors()
    {
        foreach (SpriteRenderer sr in targets)
            if (sr != null && sr.gameObject != gameObject)
                sr.color = normalColor;
    }
}
