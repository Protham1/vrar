using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;

[InitializeOnLoad]
public static class OpenDemoSceneOnLoad
{
    const string ScenePath = "Assets/Scenes/SampleScene.unity";

    static OpenDemoSceneOnLoad()
    {
        EditorApplication.delayCall += () =>
        {
            if (SessionState.GetBool("Raycast2D.Opened", false)) return;
            SessionState.SetBool("Raycast2D.Opened", true);
            if (EditorApplication.isPlayingOrWillChangePlaymode) return;

            var active = EditorSceneManager.GetActiveScene();
            if (!string.IsNullOrEmpty(active.path) || active.isDirty) return;
            if (!File.Exists(ScenePath)) return;

            EditorSceneManager.OpenScene(ScenePath);
            var sv = SceneView.lastActiveSceneView;
            if (sv != null) sv.in2DMode = true;
        };
    }
}
