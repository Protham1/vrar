Program1 - Unity project (rebuilt from the tutorial video)
Unity version: 2022.3.18f1 (Built-in Render Pipeline, legacy Input Manager)

HOW TO OPEN
1. Unzip this folder.
2. Unity Hub -> Add -> "Add project from disk" -> select the UnityProject_Program1 folder.
3. Open it with Unity 2022.3.18f1 (any 2022.3 LTS works). The first import takes a minute.
4. SampleScene opens automatically (if not: Assets/Scenes/SampleScene.unity). Press Play.

SCENE
- Plane at (0,0,0)       Default-Material   ObjectController: Move 2  / Rotate 20 / Scale 0.1
- Cube  at (-2,0.5,0)    red material       ObjectController: Move 5  / Rotate 50 / Scale 0.5
- Sphere at (2,0.5,0)    blue material      ObjectController: Move 4  / Rotate 80 / Scale 0.4
- Main Camera (0,1,-10) and Directional Light = Unity defaults

CONTROLS (the script is attached to all three objects, so they all react at once)
- Move:   W A S D (or the arrow keys, via the default Horizontal/Vertical axes)
          E = up, Q = down
- Rotate: Up Arrow = rotate around X,  Left Arrow = rotate around Y
- Scale:  hold X / Y / Z to grow the object along that axis
