using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObjectController : MonoBehaviour
{
    // Start is called before the first frame update
    public float moveSpeed = 3f;
    public float rotateSpeed = 60f;
    public float scaleSpeed = 0.3f;

    void Start()
    {

    }

    void Update()
    {
        // ===== MOVE (WASD + Q/E) =====
        float x = Input.GetAxis("Horizontal");
        float z = Input.GetAxis("Vertical");

        float y = 0;
        if (Input.GetKey(KeyCode.E)) y = 1;
        if (Input.GetKey(KeyCode.Q)) y = -1;

        transform.Translate(new Vector3(x, y, z) * moveSpeed * Time.deltaTime);

        // ===== ROTATE (ARROWS) =====
        if (Input.GetKey(KeyCode.UpArrow))
            transform.Rotate(Vector3.right * rotateSpeed * Time.deltaTime);

        if (Input.GetKey(KeyCode.LeftArrow))
            transform.Rotate(Vector3.up * rotateSpeed * Time.deltaTime);

        // ===== SCALE ON ALL AXES =====
        if (Input.GetKey(KeyCode.X))   // Scale X axis
            transform.localScale += new Vector3(scaleSpeed, 0, 0) * Time.deltaTime;

        if (Input.GetKey(KeyCode.Y))   // Scale Y axis
            transform.localScale += new Vector3(0, scaleSpeed, 0) * Time.deltaTime;

        if (Input.GetKey(KeyCode.Z))   // Scale Z axis
            transform.localScale += new Vector3(0, 0, scaleSpeed) * Time.deltaTime;
    }
}
