Program 2 - Unity project (VR/AR lab)

1. Unity Hub -> Add -> "Add project from disk" -> select this Program2VR folder.
   Use Unity 2021 LTS, 2022 LTS or Unity 6 (accept the upgrade prompt if shown).
2. Wait for the first import. The scene Assets/Scenes/Program2.unity is generated
   automatically and opened (menu Program2 > Rebuild Scene regenerates it).
3. Press Play. Characters cycle Idle > Wave > Jump > Spin. Click the WIN button
   (or press Space) to fire the "win" trigger on both characters.
