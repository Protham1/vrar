using UnityEngine;
using UnityEngine.UI;

// Attached to the UI button. Fires the "win" trigger on every character's Animator.
public class Program2Controller : MonoBehaviour
{
    public Animator[] characters;
    public Text statusText;
    public Image indicator;
    int count;

    // Wired to Button.onClick (the "VR trigger" press on the UI button)
    public void OnButtonClick() { Fire(); }

    void Update()
    {
#if ENABLE_LEGACY_INPUT_MANAGER
        // Space / first gamepad-controller button acts as the trigger too
        if (Input.GetKeyDown(KeyCode.Space) || Input.GetKeyDown(KeyCode.JoystickButton0)) Fire();
#endif
    }

    void Fire()
    {
        foreach (var a in characters)
            if (a != null) { a.ResetTrigger("win"); a.SetTrigger("win"); }
        count++;
        if (statusText != null) statusText.text = "Trigger OK - WIN played! (" + count + ")";
        if (indicator != null)
        {
            indicator.color = Color.green;
            CancelInvoke(nameof(ResetIndicator));
            Invoke(nameof(ResetIndicator), 2f);
        }
    }

    void ResetIndicator() { if (indicator != null) indicator.color = Color.gray; }
}
