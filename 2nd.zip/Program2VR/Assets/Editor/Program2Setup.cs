using System.IO;
using UnityEditor;
using UnityEditor.Animations;
using UnityEditor.Events;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

// Builds the whole Program 2 scene automatically the first time the project opens.
[InitializeOnLoad]
public static class Program2Setup
{
    const string ScenePath = "Assets/Scenes/Program2.unity";

    static Program2Setup() { EditorApplication.delayCall += AutoRun; }

    static void AutoRun()
    {
        if (EditorApplication.isPlayingOrWillChangePlaymode) return;
        if (EditorApplication.isCompiling || EditorApplication.isUpdating) { EditorApplication.delayCall += AutoRun; return; }
        if (!File.Exists(ScenePath)) Build();
        else if (string.IsNullOrEmpty(EditorSceneManager.GetActiveScene().path))
            EditorSceneManager.OpenScene(ScenePath);
    }

    [MenuItem("Program2/Rebuild Scene")]
    static void Build()
    {
        foreach (var d in new[] { "Scenes", "Animations", "Materials", "Textures" })
            Directory.CreateDirectory("Assets/" + d);
        AssetDatabase.Refresh();

        // ---------- Textures / sprites ----------
        var checker = SaveTexture("Assets/Textures/Checker.png", 64, 64, (x, y) =>
            ((x / 8 + y / 8) % 2 == 0) ? new Color(1f, 0.55f, 0.1f) : Color.white, false);
        var panelSprite = SaveSprite("Assets/Textures/Panel.png", 8, 8, (x, y) => Color.white);
        var circleSprite = SaveSprite("Assets/Textures/Circle.png", 64, 64, (x, y) =>
        {
            float dx = x - 31.5f, dy = y - 31.5f;
            return new Color(1, 1, 1, (dx * dx + dy * dy <= 30f * 30f) ? 1f : 0f);
        });

        // ---------- Materials ----------
        var cubeMat = MakeMat("CubeMat", Color.white, checker);
        var blueMat = MakeMat("CharacterBlue", new Color(0.2f, 0.45f, 0.95f));
        var redMat = MakeMat("CharacterOrange", new Color(0.95f, 0.4f, 0.2f));
        var darkMat = MakeMat("Eyes", Color.black);
        var groundMat = MakeMat("Ground", new Color(0.35f, 0.4f, 0.35f));

        // ---------- Animation clips ----------
        var idle = MakeClip("Idle", true,
            C("Model", "localPosition.y", Ks(0, 0, 0.5f, 0.06f, 1, 0)));
        var wave = MakeClip("Wave", false,
            C("Model/ArmR", "localEulerAnglesRaw.z", Ks(0, 0, 0.3f, 150, 0.6f, 110, 0.9f, 150, 1.2f, 110, 1.5f, 150, 2, 0)));
        var jump = MakeClip("Jump", false,
            C("Model", "localPosition.y", Ks(0, 0, 0.25f, 0, 0.5f, 1, 0.75f, 0, 1, 0)),
            C("Model/ArmR", "localEulerAnglesRaw.z", Ks(0, 0, 0.5f, 60, 1, 0)),
            C("Model/ArmL", "localEulerAnglesRaw.z", Ks(0, 0, 0.5f, -60, 1, 0)));
        var spin = MakeClip("Spin", false,
            C("Model", "localEulerAnglesRaw.y", new[] { new Keyframe(0, 0, 240, 240), new Keyframe(1.5f, 360, 240, 240) }));
        var win = MakeClip("Win", false,
            C("Model", "localEulerAnglesRaw.y", new[] { new Keyframe(0, 0, 360, 360), new Keyframe(2, 720, 360, 360) }),
            C("Model", "localPosition.y", Ks(0, 0, 0.5f, 0.8f, 1, 0, 1.5f, 0.8f, 2, 0)),
            C("Model/ArmR", "localEulerAnglesRaw.z", Ks(0, 0, 0.2f, 150, 1.8f, 150, 2, 0)),
            C("Model/ArmL", "localEulerAnglesRaw.z", Ks(0, 0, 0.2f, -150, 1.8f, -150, 2, 0)));

        // ---------- Animator Controller: Idle -> Wave -> Jump -> Spin -> Idle ..., Any State -> Win on trigger "win" ----------
        const string ctrlPath = "Assets/Animations/CharacterController.controller";
        AssetDatabase.DeleteAsset(ctrlPath);
        var ctrl = AnimatorController.CreateAnimatorControllerAtPath(ctrlPath);
        ctrl.AddParameter("win", AnimatorControllerParameterType.Trigger);
        var sm = ctrl.layers[0].stateMachine;
        var sIdle = AddState(sm, "Idle", idle);
        var sWave = AddState(sm, "Wave", wave);
        var sJump = AddState(sm, "Jump", jump);
        var sSpin = AddState(sm, "Spin", spin);
        var sWin = AddState(sm, "Win", win);
        sm.defaultState = sIdle;
        Chain(sIdle, sWave); Chain(sWave, sJump); Chain(sJump, sSpin); Chain(sSpin, sIdle); Chain(sWin, sIdle);
        var any = sm.AddAnyStateTransition(sWin);
        any.AddCondition(AnimatorConditionMode.If, 0, "win");
        any.hasExitTime = false;
        any.hasFixedDuration = true;
        any.duration = 0.1f;
        any.canTransitionToSelf = false;
        EditorUtility.SetDirty(ctrl);
        AssetDatabase.SaveAssets();

        // ---------- Scene ----------
        var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);

        var camGO = new GameObject("Main Camera");
        camGO.tag = "MainCamera";
        var cam = camGO.AddComponent<Camera>();
        camGO.AddComponent<AudioListener>();
        cam.clearFlags = CameraClearFlags.SolidColor;
        cam.backgroundColor = new Color(0.12f, 0.16f, 0.25f);
        camGO.transform.position = new Vector3(0, 1.8f, -7f);
        camGO.transform.LookAt(new Vector3(0, 1f, 0));

        var lightGO = new GameObject("Directional Light");
        var light = lightGO.AddComponent<Light>();
        light.type = LightType.Directional;
        lightGO.transform.rotation = Quaternion.Euler(50, -30, 0);
        RenderSettings.ambientMode = UnityEngine.Rendering.AmbientMode.Flat;
        RenderSettings.ambientLight = new Color(0.55f, 0.55f, 0.55f);

        var ground = GameObject.CreatePrimitive(PrimitiveType.Plane);
        ground.name = "Ground";
        ground.transform.localScale = new Vector3(2, 1, 2);
        ground.GetComponent<Renderer>().sharedMaterial = groundMat;

        var cube = GameObject.CreatePrimitive(PrimitiveType.Cube);
        cube.name = "Cube";
        cube.transform.position = new Vector3(0, 0.5f, 0);
        cube.transform.rotation = Quaternion.Euler(0, 25, 0);
        cube.GetComponent<Renderer>().sharedMaterial = cubeMat;

        // Character 1 and Character 2 share the SAME controller ("transfer" of animation to the second model)
        var c1 = BuildCharacter("Character1", new Vector3(-2.4f, 0, 0), blueMat, darkMat, ctrl);
        var c2 = BuildCharacter("Character2", new Vector3(2.4f, 0, 0), redMat, darkMat, ctrl);

        // ---------- UI ----------
        var canvasGO = new GameObject("Canvas", typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster));
        var canvas = canvasGO.GetComponent<Canvas>();
        canvas.renderMode = RenderMode.ScreenSpaceOverlay;
        var scaler = canvasGO.GetComponent<CanvasScaler>();
        scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        scaler.referenceResolution = new Vector2(1920, 1080);
        scaler.matchWidthOrHeight = 0.5f;

        var panel = UIObj("MenuPanel", canvasGO.transform, new Vector2(30, -30), new Vector2(520, 290));
        var panelImg = panel.AddComponent<Image>();
        panelImg.sprite = panelSprite;
        panelImg.color = new Color(0, 0, 0, 0.6f);

        MakeText(panel.transform, "Title", "Program 2 - Animation Menu", 32, new Vector2(20, -15), new Vector2(480, 45), TextAnchor.MiddleLeft);

        var icon = UIObj("Indicator", panel.transform, new Vector2(20, -80), new Vector2(40, 40));
        var iconImg = icon.AddComponent<Image>();
        iconImg.sprite = circleSprite;
        iconImg.color = Color.gray;

        var status = MakeText(panel.transform, "Status", "Waiting for trigger...", 26, new Vector2(75, -78), new Vector2(430, 45), TextAnchor.MiddleLeft);

        var btnGO = UIObj("WinButton", panel.transform, new Vector2(20, -140), new Vector2(480, 80));
        var btnImg = btnGO.AddComponent<Image>();
        btnImg.sprite = panelSprite;
        btnImg.color = new Color(0.2f, 0.45f, 0.95f);
        var btn = btnGO.AddComponent<Button>();
        btn.targetGraphic = btnImg;
        btn.navigation = new Navigation { mode = Navigation.Mode.None };
        var label = MakeText(btnGO.transform, "Label", "WIN (trigger)", 34, Vector2.zero, new Vector2(480, 80), TextAnchor.MiddleCenter);

        MakeText(panel.transform, "Hint", "Click the button (or press Space / controller trigger)", 20, new Vector2(20, -235), new Vector2(480, 40), TextAnchor.MiddleLeft);

        // Script attached to the button, wired to onClick
        var ctl = btnGO.AddComponent<Program2Controller>();
        ctl.characters = new[] { c1.GetComponent<Animator>(), c2.GetComponent<Animator>() };
        ctl.statusText = status;
        ctl.indicator = iconImg;
        UnityEventTools.AddPersistentListener(btn.onClick, ctl.OnButtonClick);

        new GameObject("EventSystem", typeof(EventSystem), typeof(StandaloneInputModule));

        EditorSceneManager.SaveScene(scene, ScenePath);
        EditorBuildSettings.scenes = new[] { new EditorBuildSettingsScene(ScenePath, true) };
        AssetDatabase.SaveAssets();
        Debug.Log("Program 2 scene built. Press Play!");
    }

    // ---------- helpers ----------
    static GameObject BuildCharacter(string name, Vector3 pos, Material mat, Material eyeMat, RuntimeAnimatorController ctrl)
    {
        var root = new GameObject(name);
        root.transform.position = pos;
        var model = new GameObject("Model");
        model.transform.SetParent(root.transform, false);
        Part(PrimitiveType.Capsule, "Body", model.transform, new Vector3(0, 1f, 0), new Vector3(0.7f, 0.7f, 0.7f), mat);
        Part(PrimitiveType.Sphere, "Head", model.transform, new Vector3(0, 1.95f, 0), Vector3.one * 0.55f, mat);
        Part(PrimitiveType.Sphere, "EyeL", model.transform, new Vector3(-0.1f, 2.0f, -0.23f), Vector3.one * 0.1f, eyeMat);
        Part(PrimitiveType.Sphere, "EyeR", model.transform, new Vector3(0.1f, 2.0f, -0.23f), Vector3.one * 0.1f, eyeMat);
        foreach (var side in new[] { "ArmL", "ArmR" })
        {
            var pivot = new GameObject(side);
            pivot.transform.SetParent(model.transform, false);
            pivot.transform.localPosition = new Vector3(side == "ArmR" ? 0.5f : -0.5f, 1.5f, 0);
            Part(PrimitiveType.Capsule, "Mesh", pivot.transform, new Vector3(0, -0.3f, 0), new Vector3(0.2f, 0.3f, 0.2f), mat);
        }
        var anim = root.AddComponent<Animator>();
        anim.runtimeAnimatorController = ctrl;
        return root;
    }

    static void Part(PrimitiveType type, string name, Transform parent, Vector3 pos, Vector3 scale, Material mat)
    {
        var go = GameObject.CreatePrimitive(type);
        Object.DestroyImmediate(go.GetComponent<Collider>());
        go.name = name;
        go.transform.SetParent(parent, false);
        go.transform.localPosition = pos;
        go.transform.localScale = scale;
        go.GetComponent<Renderer>().sharedMaterial = mat;
    }

    struct Curve { public string path, prop; public Keyframe[] keys; }
    static Curve C(string path, string prop, Keyframe[] keys) { return new Curve { path = path, prop = prop, keys = keys }; }

    static Keyframe[] Ks(params float[] timeValuePairs)
    {
        var k = new Keyframe[timeValuePairs.Length / 2];
        for (int i = 0; i < k.Length; i++) k[i] = new Keyframe(timeValuePairs[2 * i], timeValuePairs[2 * i + 1]);
        return k;
    }

    static AnimationClip MakeClip(string name, bool loop, params Curve[] curves)
    {
        var clip = new AnimationClip { name = name, frameRate = 30 };
        foreach (var c in curves) clip.SetCurve(c.path, typeof(Transform), c.prop, new AnimationCurve(c.keys));
        if (loop)
        {
            var s = AnimationUtility.GetAnimationClipSettings(clip);
            s.loopTime = true;
            AnimationUtility.SetAnimationClipSettings(clip, s);
        }
        Save(clip, "Assets/Animations/" + name + ".anim");
        return clip;
    }

    static AnimatorState AddState(AnimatorStateMachine sm, string name, Motion m)
    {
        var s = sm.AddState(name);
        s.motion = m;
        return s;
    }

    static void Chain(AnimatorState a, AnimatorState b)
    {
        var t = a.AddTransition(b);
        t.hasExitTime = true;
        t.exitTime = 1f;
        t.hasFixedDuration = true;
        t.duration = 0.1f;
    }

    static void Save(Object o, string path)
    {
        AssetDatabase.DeleteAsset(path);
        AssetDatabase.CreateAsset(o, path);
    }

    static Material MakeMat(string name, Color c, Texture tex = null)
    {
        Shader sh = Shader.Find("Standard");
        if (sh == null) sh = Shader.Find("Universal Render Pipeline/Lit");
        if (sh == null) sh = Shader.Find("Sprites/Default");
        var m = new Material(sh);
        m.color = c;
        if (tex != null) m.mainTexture = tex;
        Save(m, "Assets/Materials/" + name + ".mat");
        return m;
    }

    static Texture2D SaveTexture(string path, int w, int h, System.Func<int, int, Color> f, bool sprite)
    {
        var t = new Texture2D(w, h, TextureFormat.RGBA32, false);
        for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) t.SetPixel(x, y, f(x, y));
        t.Apply();
        File.WriteAllBytes(path, t.EncodeToPNG());
        Object.DestroyImmediate(t);
        AssetDatabase.ImportAsset(path);
        if (sprite)
        {
            var imp = (TextureImporter)AssetImporter.GetAtPath(path);
            imp.textureType = TextureImporterType.Sprite;
            imp.alphaIsTransparency = true;
            imp.SaveAndReimport();
        }
        return AssetDatabase.LoadAssetAtPath<Texture2D>(path);
    }

    static Sprite SaveSprite(string path, int w, int h, System.Func<int, int, Color> f)
    {
        SaveTexture(path, w, h, f, true);
        return AssetDatabase.LoadAssetAtPath<Sprite>(path);
    }

    static GameObject UIObj(string name, Transform parent, Vector2 pos, Vector2 size)
    {
        var go = new GameObject(name, typeof(RectTransform));
        var rt = go.GetComponent<RectTransform>();
        rt.SetParent(parent, false);
        rt.anchorMin = rt.anchorMax = rt.pivot = new Vector2(0, 1);
        rt.anchoredPosition = pos;
        rt.sizeDelta = size;
        return go;
    }

    static Text MakeText(Transform parent, string name, string txt, int size, Vector2 pos, Vector2 sz, TextAnchor anchor)
    {
        var go = UIObj(name, parent, pos, sz);
        var t = go.AddComponent<Text>();
#if UNITY_2022_2_OR_NEWER
        t.font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
#else
        t.font = Resources.GetBuiltinResource<Font>("Arial.ttf");
#endif
        t.text = txt;
        t.fontSize = size;
        t.color = Color.white;
        t.alignment = anchor;
        t.raycastTarget = false;
        return t;
    }
}
