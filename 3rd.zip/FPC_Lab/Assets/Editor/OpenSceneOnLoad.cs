using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine.SceneManagement;

// Opens SampleScene automatically the first time this project is opened.
[InitializeOnLoad]
public static class OpenSceneOnLoad
{
    const string ScenePath = "Assets/Scenes/SampleScene.unity";

    static OpenSceneOnLoad()
    {
        if (SessionState.GetBool("FPC_SceneOpened", false)) return;
        SessionState.SetBool("FPC_SceneOpened", true);
        EditorApplication.delayCall += () =>
        {
            if (SceneManager.GetActiveScene().path != ScenePath)
                EditorSceneManager.OpenScene(ScenePath);
        };
    }
}
