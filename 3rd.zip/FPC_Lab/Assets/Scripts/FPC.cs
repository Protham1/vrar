using UnityEngine;
#if ENABLE_INPUT_SYSTEM
using UnityEngine.InputSystem;
#endif

/// <summary>
/// Drop-in first-person controller. Works with the old Input Manager,
/// the new Input System, or "Both" (Project Settings > Player > Active Input Handling).
///
/// Setup: put this on your Capsule (the one with Main Camera as a child). That's it.
/// Controls: WASD move, Mouse look, Shift sprint, Space jump, Esc free cursor, click to re-lock.
/// </summary>
[RequireComponent(typeof(CharacterController))]
public class FPC : MonoBehaviour
{
    [Header("Movement")]
    public float walkSpeed = 5f;
    public float sprintSpeed = 8f;
    public float jumpHeight = 1.2f;
    public float gravity = -20f;

    [Header("Look")]
    public float mouseSensitivity = 0.12f;   // degrees per mouse count
    public float maxPitch = 85f;

    [Header("Camera")]
    public Transform cameraTransform;        // auto-found if left empty
    public float eyeHeight = 0.6f;           // local Y of camera inside the capsule

    CharacterController controller;
    float pitch;
    float verticalVelocity;

    void Awake()
    {
        controller = GetComponent<CharacterController>();

        // A CapsuleCollider next to a CharacterController is redundant; remove it.
        var capsule = GetComponent<CapsuleCollider>();
        if (capsule != null) Destroy(capsule);

        if (cameraTransform == null)
        {
            var cam = GetComponentInChildren<Camera>();
            if (cam == null) cam = Camera.main;
            if (cam != null) cameraTransform = cam.transform;
        }

        if (cameraTransform != null)
        {
            cameraTransform.localPosition = new Vector3(0f, eyeHeight, 0f);
            cameraTransform.localRotation = Quaternion.identity;
        }

        LockCursor(true);
    }

    void Update()
    {
        HandleCursor();
        if (Cursor.lockState != CursorLockMode.Locked) return;

        Look();
        Move();
    }

    void Look()
    {
        Vector2 look = ReadLook() * mouseSensitivity;

        transform.Rotate(Vector3.up, look.x);

        pitch = Mathf.Clamp(pitch - look.y, -maxPitch, maxPitch);
        if (cameraTransform != null)
            cameraTransform.localRotation = Quaternion.Euler(pitch, 0f, 0f);
    }

    void Move()
    {
        Vector2 input = ReadMove();
        float speed = SprintHeld() ? sprintSpeed : walkSpeed;

        Vector3 move = (transform.right * input.x + transform.forward * input.y);
        if (move.sqrMagnitude > 1f) move.Normalize();
        move *= speed;

        if (controller.isGrounded && verticalVelocity < 0f)
            verticalVelocity = -2f; // keeps the controller stuck to the ground

        if (controller.isGrounded && JumpPressed())
            verticalVelocity = Mathf.Sqrt(jumpHeight * -2f * gravity);

        verticalVelocity += gravity * Time.deltaTime;
        move.y = verticalVelocity;

        controller.Move(move * Time.deltaTime);
    }

    // ---------- Cursor ----------

    void HandleCursor()
    {
        if (EscPressed()) LockCursor(false);
        else if (Cursor.lockState != CursorLockMode.Locked && ClickPressed()) LockCursor(true);
    }

    static void LockCursor(bool locked)
    {
        Cursor.lockState = locked ? CursorLockMode.Locked : CursorLockMode.None;
        Cursor.visible = !locked;
    }

    // ---------- Input abstraction (new Input System preferred, legacy fallback) ----------

#if ENABLE_INPUT_SYSTEM
    static Vector2 ReadMove()
    {
        var k = Keyboard.current;
        if (k == null) return Vector2.zero;
        float x = (k.dKey.isPressed ? 1f : 0f) - (k.aKey.isPressed ? 1f : 0f);
        float y = (k.wKey.isPressed ? 1f : 0f) - (k.sKey.isPressed ? 1f : 0f);
        return new Vector2(x, y);
    }

    static Vector2 ReadLook() => Mouse.current != null ? Mouse.current.delta.ReadValue() : Vector2.zero;
    static bool SprintHeld() => Keyboard.current != null && Keyboard.current.leftShiftKey.isPressed;
    static bool JumpPressed() => Keyboard.current != null && Keyboard.current.spaceKey.wasPressedThisFrame;
    static bool EscPressed() => Keyboard.current != null && Keyboard.current.escapeKey.wasPressedThisFrame;
    static bool ClickPressed() => Mouse.current != null && Mouse.current.leftButton.wasPressedThisFrame;
#else
    static Vector2 ReadMove() => new Vector2(Input.GetAxisRaw("Horizontal"), Input.GetAxisRaw("Vertical"));
    // Legacy mouse axes are already in "counts"; scale to match the new-system feel.
    static Vector2 ReadLook() => new Vector2(Input.GetAxisRaw("Mouse X"), Input.GetAxisRaw("Mouse Y")) * 8f;
    static bool SprintHeld() => Input.GetKey(KeyCode.LeftShift);
    static bool JumpPressed() => Input.GetKeyDown(KeyCode.Space);
    static bool EscPressed() => Input.GetKeyDown(KeyCode.Escape);
    static bool ClickPressed() => Input.GetMouseButtonDown(0);
#endif
}
